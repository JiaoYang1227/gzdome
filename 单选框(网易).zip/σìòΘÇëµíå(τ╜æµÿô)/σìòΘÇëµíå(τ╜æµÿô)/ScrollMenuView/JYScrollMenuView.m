//
//  ScrollMenuView.m
//  单选框(网易)
//
//  Created by sun on 16/7/5.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "JYScrollMenuView.h"
//#define INDICATE_HEIGHT   [UIScreen mainScreen].scale
//#define LINE_HEIGHT INDICATE_HEIGHT/2
#define INDICATE_HEIGHT   3
#define LINE_HEIGHT [UIScreen mainScreen].scale/2
@interface JYScrollMenuView()
{
  
}
@property (nonatomic,strong) UIScrollView *scrollView;;
@property(nonatomic,strong) UIView *indicateView;

@end

@implementation JYScrollMenuView
-(void)setItems:(NSArray *)items{
    _items = items;
    [self reloadData:YES];
}
-(void)reloadData
{
    [self reloadData:NO];
}
-(void)reloadData:(BOOL)layout{
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.scrollView = nil;
    [self addSubview:self.scrollView];
    [_buttons removeAllObjects];
    
    __block float contentSize = 0;
    
    for(int idx=0;idx<[self.items count];idx++){
        id item = [self.items objectAtIndex:idx];
        
        UIButton *buttonItem = [UIButton buttonWithType:UIButtonTypeCustom];
        if (_titleForMenuScrollItem) {
            [buttonItem setTitle:_titleForMenuScrollItem(idx,item) forState:UIControlStateNormal];
            
        }
        [buttonItem setTitleColor:self.itemNormalColor?:[UIColor colorWithRed:0.800 green:0.000 blue:0.200 alpha:1.000] forState:UIControlStateNormal];
        [buttonItem setTitleColor:self.itemSelectColor?:[UIColor colorWithRed:0.800 green:0.000 blue:0.200 alpha:1.000] forState:UIControlStateSelected];
        buttonItem.titleLabel.textAlignment = NSTextAlignmentCenter;
        buttonItem.titleLabel.font = [UIFont boldSystemFontOfSize:14.0];
        buttonItem.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        buttonItem.titleLabel.numberOfLines = 1;
        
        buttonItem.backgroundColor = [UIColor clearColor];
        
        buttonItem.titleEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
        
        NSString *title = buttonItem.titleLabel.text;
        
        
        CGFloat width = (_itemWidth>0.0)?_itemWidth:[self widthWithString:title fontSize:15 height:15]+10;
        
        buttonItem.frame = CGRectMake(contentSize,0 ,width, CGRectGetHeight(self.scrollView.frame)-LINE_HEIGHT-INDICATE_HEIGHT);
        contentSize += width;
        
        buttonItem.tag = 20000 + idx;
        [buttonItem addTarget:self action:@selector(touchButtonAction:) forControlEvents:UIControlEventTouchDown];
        [self.scrollView addSubview:buttonItem];
        if (!_buttons) {
            _buttons = [NSMutableArray array];
        }
        [_buttons addObject:buttonItem];
    }

    self.scrollView.contentSize = CGSizeMake(contentSize, 0);
    [self.scrollView addSubview:self.indicateView];

    
    UIView *border = [[UIView alloc] init];
    border.backgroundColor = [UIColor colorWithRed:0.835 green:0.851 blue:0.847 alpha:1.000];
    border.frame = CGRectMake(0, self.frame.size.height - LINE_HEIGHT, self.frame.size.width, LINE_HEIGHT);
    [self insertSubview:border belowSubview:self.scrollView];
    
    
   [self touchAction:[_buttons firstObject] layout:layout];

}
-(UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        _scrollView.directionalLockEnabled = YES;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.canCancelContentTouches = YES;
        _scrollView.backgroundColor = [UIColor clearColor];
    }
    return _scrollView;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self reloadData:YES];
}
-(UIView *)indicateView{
    if (!_indicateView) {
        _indicateView = [[UIView alloc]init];
        _indicateView.backgroundColor = [UIColor colorWithRed:0.800 green:0.000 blue:0.200 alpha:1.000];
        _indicateView.layer.zPosition = 100;
    }
    UIButton *button = [_buttons firstObject];
    _indicateView.frame = CGRectMake(0, self.scrollView.frame.size.height-INDICATE_HEIGHT, CGRectGetWidth(button.frame), INDICATE_HEIGHT);
    return _indicateView;
}

-(void)didClickMenuItem:(TouchMenuScrollView)touchMenuScrollView{
    _touchMenuScrollView = [touchMenuScrollView copy];
    [self reloadData:NO];
}
-(void)titleForMenuItem:(TitleForMenuScrollItem)titleForMenuScrollItem{
    _titleForMenuScrollItem = [titleForMenuScrollItem copy];
    [self reloadData:YES];
}
-(void)setItemNormalColor:(UIColor *)itemNormalColor{
    _itemNormalColor = itemNormalColor;
    [self reloadData:YES];

}
-(void)setItemSelectColor:(UIColor *)itemSelectColor{
    _itemSelectColor = itemSelectColor;
    [self reloadData:YES];
    
}
-(void)setItemWidth:(CGFloat)itemWidth{
    _itemWidth = itemWidth;
    [self reloadData:YES];
}
- (void)touchButtonAction:(UIButton*)sender{
    [self touchAction:sender layout:NO];
}
- (void)touchAction:(UIButton*)sender layout:(BOOL)layout
{
    for (UIButton *button in _buttons) {
        if ([button isKindOfClass:[UIButton class]]) {
            if (button == sender) {
                [UIView animateWithDuration:0.3 animations:^{
                    CGPoint point = self.indicateView.center;
                    CGRect frame = button.frame;
                    frame.origin.y = self.indicateView.frame.origin.y;
                    frame.size.height = self.indicateView.frame.size.height;
                    point.x = button.center.x;
                    self.indicateView.frame = frame;
                    button.titleLabel.font = [UIFont systemFontOfSize:15.0];
                    button.selected = YES;
                }];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    _currentItem = [self.items objectAtIndex:sender.tag-20000];
                    _selectedIndex = sender.tag-20000;
                    if (_touchMenuScrollView && !layout) {
                        _touchMenuScrollView(sender.tag-20000,sender,[self.items objectAtIndex:sender.tag-20000]);
                    }
                });
            }else
            {
                button.titleLabel.font = [UIFont systemFontOfSize:14.0];
                button.selected = NO;

            }
        }
        
    }
}
-(void)setSelectedIndex:(NSInteger)selectedIndex{
    _selectedIndex = selectedIndex;
    [self touchAction:_buttons[selectedIndex] layout:NO];
}
- (CGFloat)widthWithString:(NSString*)string fontSize:(CGFloat)fontSize height:(CGFloat)height
{
    NSDictionary *attrs = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:fontSize]};
    return  [string boundingRectWithSize:CGSizeMake(0, height) options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attrs context:nil].size.width;
}
@end
