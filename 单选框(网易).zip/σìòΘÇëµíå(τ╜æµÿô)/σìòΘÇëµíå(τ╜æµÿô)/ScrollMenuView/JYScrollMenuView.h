//
//  ScrollMenuView.h
//  单选框(网易)
//
//  Created by sun on 16/7/5.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^TouchMenuScrollView)(NSInteger index,UIButton *button,id item);
typedef NSString*(^TitleForMenuScrollItem)(NSInteger index,id item);

@interface JYScrollMenuView : UIView
{
    
    TouchMenuScrollView _touchMenuScrollView;
    NSMutableArray *_buttons;
    TitleForMenuScrollItem _titleForMenuScrollItem;
}
@property(nonatomic,strong) NSArray *items;
@property(nonatomic,strong) UIColor *itemNormalColor;
@property(nonatomic,strong) UIColor *itemSelectColor;
@property(nonatomic,assign) CGFloat itemWidth;

@property(nonatomic,strong) id currentItem;

@property(nonatomic,assign) NSInteger selectedIndex;

-(void)didClickMenuItem:(TouchMenuScrollView)touchMenuScrollView;
-(void)titleForMenuItem:(TitleForMenuScrollItem)titleForMenuScrollItem;
-(void)reloadData;
@end