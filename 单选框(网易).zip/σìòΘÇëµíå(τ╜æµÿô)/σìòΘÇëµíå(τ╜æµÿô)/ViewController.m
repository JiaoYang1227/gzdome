//
//  ViewController.m
//  单选框(网易)
//
//  Created by sun on 16/7/5.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   [self MenuLoadandClicked];
}
-(void)MenuLoadandClicked{
    self.menuView.items = @[@"e-tron",@"connect",@"MMI",@"quattro",@"powertain"];
    self.menuView.itemNormalColor = [UIColor colorWithWhite:0.263 alpha:1.000];
    self.menuView.itemSelectColor = [UIColor colorWithRed:0.569 green:0.039 blue:0.039 alpha:1.000];
    [self.menuView titleForMenuItem:^NSString *(NSInteger index, id item) {
        return [item description];
    }];
    [self.menuView didClickMenuItem:^(NSInteger index, UIButton *button, id item) {
        //选中操作
        NSLog(@"选中第%ld个:%@",(long)index,[item description]);
    }];
    self.menuView.itemWidth = [UIScreen mainScreen].bounds.size.width/5.0;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
