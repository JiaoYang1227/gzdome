//
//  ViewController.m
//  2121212
//
//  Created by sun on 16/1/15.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "ViewController.h"
#import "DXAlertView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)MyAlertView:(id)sender {
    DXAlertView *alert = [[DXAlertView alloc]initWithTitle:@"该吃药了" contentText1:@"服用药品：名称" contentText2:@"服用时间：时间"  leftButtonTitle:nil rightButtonTitle:@"知道了，这就去"];
    [alert show];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
