//
//  AppDelegate.m
//  miyu
//
//  Created by sun on 16/1/15.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DXAlertView : UIView

- (id)initWithTitle:(NSString *)title
       contentText1:(NSString *)content1
       contentText2:(NSString *)content2
    leftButtonTitle:(NSString *)leftTitle
   rightButtonTitle:(NSString *)rigthTitle;

- (void)show;


@end
