//
//  ViewController.h
//  广告栏
//
//  Created by sun on 16/3/23.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JYScrollFocus.h"
@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet JYScrollFocus *scrollFocus;

@end

