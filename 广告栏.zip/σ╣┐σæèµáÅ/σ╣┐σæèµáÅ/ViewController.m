//
//  ViewController.m
//  广告栏
//
//  Created by sun on 16/3/23.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "ViewController.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *ima;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getData];

//    NSURL *url = [NSURL URLWithString:@"http://img1.shougongke.com/Public/data/version/201603/145861834620694.jpg"];
//    NSData *data = [NSData dataWithContentsOfURL:url];
//    UIImage *img = [UIImage imageWithData:data];
//    [self.ima setImageWithURL:url];
    
    
}
-(void)getData{
    self.scrollFocus.imageArray = @[@"70pic.jpg",@"72pic.jpg",@"70pic.jpg"];
//    self.scrollFocus.imageArray = @[@"http://img1.shougongke.com/Public/data/version/201603/145861834620694.jpg",@"http://img4.shougongke.com/Public/images/app/index02.jpg",@"http://img4.shougongke.com/Public/images/app/index03.jpg"];
    self.scrollFocus.titleArray = @[@"图片一",@"图片二",@"图片三"];
    self.scrollFocus.autoScroll = YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
