//
//  MyPageControl.m
//  audi-services
//
//  Created by Jakey on 15/2/5.
//  Copyright (c) 2015年 roirain. All rights reserved.
//

#import "MyPageControl.h"

@implementation MyPageControl


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
}

-(void)buidView{
    self.backgroundColor = [UIColor clearColor];
    
    CGFloat dotsWidth = self.numberOfPages * self.itemWidth + MAX(0, self.numberOfPages - 1) * self.itemMargin;
    CGFloat x = CGRectGetMidX(self.bounds) - dotsWidth / 2 ;
    CGFloat y = CGRectGetMidY(self.bounds) - self.itemWidth / 2 ;
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    for (int i = 0; i < self.numberOfPages; i++)
    {
        CGRect dotRect;
        
        if (i == self.currentPage)
        {
            dotRect = CGRectMake(x, y, self.itemWidth, self.itemWidth) ;
            UIImageView *normalImageImage = [[UIImageView alloc] initWithImage:self.normalImage];
            normalImageImage.frame = dotRect;
            [self addSubview:normalImageImage];
            
            CGRect dotRect = CGRectMake(x-1, y-1, self.itemWidth+2, self.itemWidth+2) ;
            
            //CGContextSetFillColorWithColor(context, drawOnColor.CGColor);
           // CGContextFillRect(context, dotRect);
            //[seletedImage drawInRect:dotRect];
            
            _selectImageImageView = [[UIImageView alloc] initWithImage:self.selectImage];
            _selectImageImageView.frame = dotRect;
            [self addSubview:_selectImageImageView];
            
            
        }
        else
        {
            dotRect = CGRectMake(x, y, self.itemWidth, self.itemWidth) ;
            UIImageView *normalImageImage = [[UIImageView alloc] initWithImage:self.normalImage];
            normalImageImage.frame = dotRect;
            [self addSubview:normalImageImage];
            //CGContextSetFillColorWithColor(context, drawOffColor.CGColor);
           // CGContextFillRect(context, dotRect);
            
        }
        
        x += self.itemWidth + self.itemMargin;
    }

    
}

- (void)setCurrentPage:(NSInteger)pageNumber
{
    if (_currentPage == pageNumber)
        return ;
    _currentPage = MIN(MAX(0, pageNumber), _numberOfPages - 1) ;
    
    CGFloat dotsWidth = self.numberOfPages * self.itemWidth + MAX(0, self.numberOfPages - 1) * self.itemMargin;
    CGFloat x = CGRectGetMidX(self.bounds) - dotsWidth / 2 ;
    [self bringSubviewToFront:_selectImageImageView];
    
    CGRect newRect = CGRectMake((self.itemWidth + self.itemMargin) * _currentPage+x-1, _selectImageImageView.frame.origin.y, _selectImageImageView.frame.size.width, _selectImageImageView.frame.size.height);
    
    [UIView animateWithDuration:0.3f delay:0.0 options:UIViewAnimationOptionCurveEaseIn animations:^(void){
            _selectImageImageView.frame = newRect;
        } completion:^(BOOL finished){
        
    }];
    

}

- (void)setNumberOfPages:(NSInteger)numOfPages
{
    _numberOfPages = MAX(0, numOfPages) ;
    
    _currentPage = MIN(MAX(0,_currentPage),_numberOfPages - 1) ;
    
    self.bounds = self.bounds ;
    [self buidView] ;
}

-(void)setClickHandler:(TouchedBlock)touchHandler{
    if (touchHandler) {
        _touchHandler = [touchHandler copy];
    }
}

@end
