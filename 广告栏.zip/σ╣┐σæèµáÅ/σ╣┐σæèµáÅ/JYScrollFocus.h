//
//  JKScrollFocus.h
//  广告栏
//
//  Created by sun on 16/3/23.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^DidSelectScrollFocusItem)(NSInteger index);
typedef void (^DownloadFocusItem)(id downloadItem,UIImageView *currentImageView);



@interface JYScrollFocus : UIView<UIScrollViewDelegate> {
    DidSelectScrollFocusItem _didSelectScrollFocusItem;
    DownloadFocusItem _downloadFocusItem;
    NSInteger _currentPageIndex;
}
@property (nonatomic, strong)NSArray *imageArray;
@property (nonatomic, strong)NSArray *titleArray;
@property (nonatomic, assign) BOOL autoScroll;

-(void)didSelectScrollFocusItem:(DidSelectScrollFocusItem)didSelectScrollFocusItem;
-(void)downloadFocusItem:(DownloadFocusItem)downloadFocusItem;

@end
