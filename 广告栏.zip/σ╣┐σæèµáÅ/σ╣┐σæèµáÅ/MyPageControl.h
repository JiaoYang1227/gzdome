//
//  MyPageControl.h
//  audi-services
//
//  Created by Jakey on 15/2/5.
//  Copyright (c) 2015年 roirain. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^TouchedBlock)(NSInteger tag);

@interface MyPageControl : UIView
{
    TouchedBlock _touchHandler;
    UIImageView *_selectImageImageView;
}
-(void)setClickHandler:(TouchedBlock)touchHandler;

@property(nonatomic) NSInteger numberOfPages;
@property(nonatomic) NSInteger currentPage;


@property (nonatomic) UIImage *normalImage;
@property (nonatomic) UIImage *selectImage;


@property (nonatomic) CGFloat itemWidth;
@property (nonatomic) CGFloat itemMargin;

@end
