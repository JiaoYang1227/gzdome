//
//  ViewController.m
//  JYAlert
//
//  Created by sun on 2016/12/15.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "ViewController.h"
#import "JYToast.h"
#import "JYAlert.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)toast:(id)sender {
    [JYToast toastWithText:@"我是JYToast"];
}
- (IBAction)alert:(id)sender {
    JYAlert *alert = [JYAlert alertWithTitle:@"提示" andMessage:@"抱歉您闯关失败，是否继续"];
    [alert addCancleButtonWithTitle:@"是" handler:^(JYAlertItem *item) {
        
    }];
    [alert addCommonButtonWithTitle:@"否" handler:^(JYAlertItem *item) {
        if (_backButtonTouchedCallback) {
            _backButtonTouchedCallback(0,0,@(NO));
        }
        [self.navigationController popViewControllerAnimated:YES];
    }];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
