//
//  main.m
//  JYAlert
//
//  Created by sun on 2016/12/15.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
