//
//  JKAlert.h
//  JKAlert
//
//  Created by Jakey on 15/1/20.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, JYALERT_ITEM_TYPE) {
    JYALERT_ITEM_TYPE_OK,
    JYALERT_ITEM_TYPE_CANCEL,
    JYALERT_ITEM_TYPE_OTHER
};

typedef NS_ENUM(NSUInteger, JYALERT_STYLE) {
    JYALERT_STYLE_ALERT,
    JYALERT_STYLE_ACTION_SHEET
};
@class JYAlertItem;
typedef void(^JYAlertHandler)(JYAlertItem *item);

@interface UIAlertController (Rotation)
//fixed UIAlertController Rotation crash bug
@end


@interface JYAlert : NSObject
- (instancetype)init __attribute__((unavailable("Forbidden use init!")));

@property(nonatomic,readonly) NSArray *actions;
/**
 *  @brief  instance init method
 *
 *  @param title   alert tiltle
 *  @param message alert message
 *  @param style   JYAlert Style
 *
 *  @return JYAlert
 */
//-(id)initWithTitle:(NSString *)title andMessage:(NSString *)message style:(JYALERT_STYLE)style;
/**
 *  @brief  class init method
 *
 *  @param title   alert tiltle
 *  @param message alert message
 *
 *  @return JYAlert with JYALERT_STYLE_ALERT
 */
+(id)alertWithTitle:(NSString *)title andMessage:(NSString *)message;
/**
 *  @brief  class init method
 *
 *  @param title   actionSheet tiltle
 *  @param message actionSheet message
 *
 *  @return JYAlert with JYALERT_STYLE_ACTION_SHEET
 */
+(id)actionSheetWithTitle:(NSString *)title andMessage:(NSString *)message;
/**
 *  @brief  add a common button without handler block
 *
 *  @param title button title
 *
 *  @return button index
 */
-(NSInteger)addButtonWithTitle:(NSString *)title;
/**
 *  @brief  add a cancle button
 *
 *  @param title   button title
 *  @param handler handler block
 */
-(void)addCancleButtonWithTitle:(NSString *)title handler:(JYAlertHandler)handler;
/**
 *  @brief  add a common button
 *
 *  @param title   button title
 *  @param handler handler block
 */
-(void)addCommonButtonWithTitle:(NSString *)title handler:(JYAlertHandler)handler;
/**
 *  @brief  find button title with buttonIndex
 *
 *  @param buttonIndex buttonIndex
 *
 *  @return button title
 */
-(NSString *)buttonTitleAtIndex:(NSInteger)buttonIndex;
/**
 *  @brief  show a alert with JYALERT_STYLE_ALERT
 *
 *  @param title   alert tiltle
 *  @param message alert message
 */
+(id)showMessage:(NSString *)title message:(NSString *)message;
/**
 *  @brief  show a alert with JYALERT_STYLE_ALERT
 *
 *  @param message alert message
 */
+(id)showMessage:(NSString *)message;
/**
 *  @brief  show method
 */
-(void)show;
@end


@interface JYAlertItem : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic) JYALERT_ITEM_TYPE type;
@property (nonatomic) NSUInteger tag;
@property (nonatomic, copy) JYAlertHandler action;
@end
