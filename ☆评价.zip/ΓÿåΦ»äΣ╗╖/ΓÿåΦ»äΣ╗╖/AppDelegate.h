//
//  AppDelegate.h
//  ☆评价
//
//  Created by sun on 16/4/13.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

