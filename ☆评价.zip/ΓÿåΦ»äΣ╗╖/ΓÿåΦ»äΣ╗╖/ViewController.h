//
//  ViewController.h
//  ☆评价
//
//  Created by sun on 16/4/13.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JYRatingView.h"
@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet JYRatingView *starView;
@end

