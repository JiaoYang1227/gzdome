//
//  UserModel.h
//  JYSQL
//
//  Created by sun on 2016/12/8.
//  Copyright © 2016年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserModel : NSObject
#pragma mark - DB
//创建表
+ (void)createCarVideoTable;
/**
 *  插入
 *
 *  @return 更新结果
 */
+(BOOL)insertWithDic:(NSDictionary *) dic;
/**
 *  查询所有已经下载的视频
 *
 *  @param userId     用户id(不用id不填,返回全部)
 *
 *  @return 更新结果
 */
+ (NSArray *)findAllDownListWithuserId:(NSString *)userId;
/**
 *  删除
 *
 *  @param userId     用户id
 *
 */
+ (void)deleteWithId:(NSString *)userId;
@end
