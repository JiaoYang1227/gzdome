//
//  UserModel.m
//  JYSQL
//
//  Created by sun on 2016/12/8.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "UserModel.h"
#import "DBManager.h"
#define JYSQLTableName @"myUser"
@implementation UserModel
//创建表
+ (void)createCarVideoTable{
    DBManager *manager = [DBManager managerWithDocumentName:@"JYSQL.sqlite"];
    if (![manager isExistTable:JYSQLTableName]) {
        //创建表,createTable:表名    fields:表字段,默认第一个是主键
        [manager createTable:JYSQLTableName fields:@[@"userid",@"name",@"age",@"CharmValue"]];
    }
    [manager close];
}
/**
 *  插入
 *
 *  @return 更新结果
 */
+(BOOL)insertWithDic:(NSDictionary *) dic{//注意插入的dic要根据创建的表的字段来插入!
    [self createCarVideoTable];
    DBManager *manager = [DBManager managerWithDocumentName:@"JYSQL.sqlite"];
    BOOL result = [manager insert:JYSQLTableName data:dic replace:YES];
    [manager close];
    return result;
    
}
/**
 *  查询所有已经下载的视频
 *
 *  @param userId     用户id(不用id不填,返回全部)
 *
 *  @return 更新结果
 */
+ (NSArray *)findAllDownListWithuserId:(NSString *)userId{
    DBManager *manager = [DBManager managerWithDocumentName:@"JYSQL.sqlite"];
    NSArray *arrData;
    if (!userId) {
        arrData = [manager select:nil from:JYSQLTableName where:nil groupBy:nil order:nil limit:nil];
    }else{
        arrData = [manager select:nil from:JYSQLTableName where:[NSString stringWithFormat:@"userid = '%@'",userId] groupBy:nil order:nil limit:nil];
    }
    [manager close];
    
    return arrData;
}
/**
 *  删除
 *
 *  @param userId     用户id
 *
 */
+ (void)deleteWithId:(NSString *)userId
{
    DBManager *mageger = [DBManager managerWithDocumentName:@"JYSQL.sqlite"];
    [mageger delete:JYSQLTableName where:[NSString stringWithFormat:@"userId = '%@'",userId] limit:nil];
    [mageger close];
}
@end
