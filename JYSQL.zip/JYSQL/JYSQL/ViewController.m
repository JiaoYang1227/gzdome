//
//  ViewController.m
//  JYSQL
//
//  Created by sun on 2016/12/8.
//  Copyright © 2016年 sun. All rights reserved.
//

#import "ViewController.h"
#import "UserModel.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //注意要加libsqlite3.0.tbd
    
    
    NSMutableDictionary *dic1 = [[NSMutableDictionary alloc]init];
    //插入数据库的字典,要根据创建数据库的表字段来对应
    [dic1 setObject:@"007" forKey:@"userid"];
    [dic1 setObject:@"焦帅帅" forKey:@"name"];
    [dic1 setObject:@"18" forKey:@"age"];
    [dic1 setObject:@"n的n次方" forKey:@"CharmValue"];
    [UserModel insertWithDic:dic1];
    
    
    NSArray *arrall = [UserModel findAllDownListWithuserId:nil];
    NSLog(@"我是全部:%@",arrall);
    
    
    NSMutableDictionary *dic2 = [[NSMutableDictionary alloc]init];
    //插入数据库的字典,要根据创建数据库的表字段来对应
    [dic2 setObject:@"008" forKey:@"userid"];
    [dic2 setObject:@"y徐丑鬼" forKey:@"name"];
    [dic2 setObject:@"80" forKey:@"age"];
    [dic2 setObject:@"0" forKey:@"CharmValue"];
    [UserModel insertWithDic:dic2];
    
    
    NSArray *arrall1 = [UserModel findAllDownListWithuserId:nil];
    NSLog(@"我是加入新数据后全部:%@",arrall1);
    
    NSLog(@"我是007:%@",[UserModel findAllDownListWithuserId:@"007"]);
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
